ML_hw3_x.c = code of Problem x
