O1 = zeros(5,1);
O2 = zeros(5,1);
O3 = zeros(5,1);
O4 = zeros(5,1);
O5 = zeros(5,1);

SV_dis = zeros(7291,1);

[input_scale_label, input_scale_inst] = libsvmread('./inputz');
[input2_scale_label, input2_scale_inst] = libsvmread('./inputzz');

train_data = input_scale_inst(1:7291,:); 
train_label = input_scale_label(1:7291,:); 
test_data = input2_scale_inst(1:2007,:); 
test_label = input2_scale_label(1:2007,:); 

model = svmtrain(train_label,train_data, '-s 0 -t 2 -c 0.001 -g 100 '    ); 
 
[predict_label, accuracy, dec_values] = svmpredict(test_label, test_data, model); % test the training data 
A = zeros(model.totalSV,model.totalSV);

K = zeros(model.totalSV,model.totalSV);

B_label = zeros(model.totalSV,1);





for i = 1:model.totalSV,
    for j =1:model.totalSV,
        K(i,j) = exp(-100*norm(model.SVs(i,:)-model.SVs(j,:))^2);
        A(i,j) = model.sv_coef(i) * model.sv_coef(j);
    end;
end;

S = A.*K;
SS = sum(S(:)); %||w||^2

B_label(1:model.totalSV) = train_label(model.sv_indices(1:model.totalSV));
B = model.sv_coef(1:model.totalSV)./(2*B_label(1:model.totalSV)-1);
BU = [];
nBU = 0;
for i=1:model.totalSV,
    if B(i) > -0.001
        BU = [BU ; model.sv_indices(i)];
        nBU = nBU + 1;
    end;
end;
B_dec = zeros(nBU,1);
for i =1:nBU,
    tmp = 0;
    for j = 1:model.totalSV,
        tmp = tmp + model.sv_coef(j) * K(j,i);
    end;
    B_dec(i) = (2*train_label(BU(i))-1)*(tmp -model.rho);
end;

B_dis = sqrt(abs(B_dec(1:nBU)).^2/SS);
O1(1) = nBU;
tmpSV_dis = zeros(7291,1);
tmpSV_dis(BU(1:nBU)) = B_dis(1:nBU);
for i = 1:7291,
    if SV_dis(i) ~= 0,
        if SV_dis(i) <= tmpSV_dis(i),
            O1(1) = -nBU;
        end;
    end;    
end;
SV_dis(BU(1:nBU)) = B_dis(1:nBU);



O2(1) = (-0.5*SS +2.380630)/0.001;
O3(1) = model.totalSV;
O4(1) = accuracy(2);
O5(1) = -2.380630;

model = svmtrain(train_label,train_data, '-s 0 -t 2 -c 0.01 -g 100 '    ); 
 
[predict_label, accuracy, dec_values] = svmpredict(test_label, test_data, model); % test the training data 
A = zeros(model.totalSV,model.totalSV);

K = zeros(model.totalSV,model.totalSV);

B_label = zeros(model.totalSV,1);





for i = 1:model.totalSV,
    for j =1:model.totalSV,
        K(i,j) = exp(-100*norm(model.SVs(i,:)-model.SVs(j,:))^2);
        A(i,j) = model.sv_coef(i) * model.sv_coef(j);
    end;
end;

S = A.*K;
SS = sum(S(:)); %||w||^2

B_label(1:model.totalSV) = train_label(model.sv_indices(1:model.totalSV));
B = model.sv_coef(1:model.totalSV)./(2*B_label(1:model.totalSV)-1);
BU = [];
nBU = 0;
for i=1:model.totalSV,
    if B(i) > -0.01
        BU = [BU ; model.sv_indices(i)];
        nBU = nBU + 1;
    end;
end;
B_dec = zeros(nBU,1);
for i =1:nBU,
    tmp = 0;
    for j = 1:model.totalSV,
        tmp = tmp + model.sv_coef(j) * K(j,i);
    end;
    B_dec(i) = (2*train_label(BU(i))-1)*(tmp -model.rho);
end;

B_dis = sqrt(abs(B_dec(1:nBU)).^2/SS);
O1(2) = nBU;
tmpSV_dis = zeros(7291,1);
tmpSV_dis(BU(1:nBU)) = B_dis(1:nBU);
for i = 1:7291,
    if SV_dis(i) ~= 0,
        if SV_dis(i) <= tmpSV_dis(i),
            O1(2) = -nBU;
        end;
    end;    
end;
SV_dis(BU(1:nBU)) = B_dis(1:nBU);



O2(2) = (-0.5*SS +23.145040)/0.01;
O3(2) = model.totalSV;
O4(2) = accuracy(2);
O5(2) = -23.145040;



model = svmtrain(train_label,train_data, '-s 0 -t 2 -c 0.1 -g 100 '    ); 
 
[predict_label, accuracy, dec_values] = svmpredict(test_label, test_data, model); % test the training data 
 
A = zeros(model.totalSV,model.totalSV);

K = zeros(model.totalSV,model.totalSV);

B_label = zeros(model.totalSV,1);





for i = 1:model.totalSV,
    for j =1:model.totalSV,
        K(i,j) = exp(-100*norm(model.SVs(i,:)-model.SVs(j,:))^2);
        A(i,j) = model.sv_coef(i) * model.sv_coef(j);
    end;
end;

S = A.*K;
SS = sum(S(:)); %||w||^2

B_label(1:model.totalSV) = train_label(model.sv_indices(1:model.totalSV));
B = model.sv_coef(1:model.totalSV)./(2*B_label(1:model.totalSV)-1);
BU = [];
nBU = 0;
for i=1:model.totalSV,
    if B(i) > -0.1
        BU = [BU ; model.sv_indices(i)];
        nBU = nBU + 1;
    end;
end;
B_dec = zeros(nBU,1);
for i =1:nBU,
    tmp = 0;
    for j = 1:model.totalSV,
        tmp = tmp + model.sv_coef(j) * K(j,i);
    end;
    B_dec(i) = (2*train_label(BU(i))-1)*(tmp -model.rho);
end;

B_dis = sqrt(abs(B_dec(1:nBU)).^2/SS);
O1(3) = nBU;
tmpSV_dis = zeros(7291,1);
tmpSV_dis(BU(1:nBU)) = B_dis(1:nBU);
for i = 1:7291,
    if SV_dis(i) ~= 0,
        if SV_dis(i) <= tmpSV_dis(i),
            O1(3) = -nBU;
        end;
    end;    
end;
SV_dis(BU(1:nBU)) = B_dis(1:nBU);



O2(3) = (-0.5*SS +178.198722)/0.1;
O3(3) = model.totalSV;
O4(3) = accuracy(2);
O5(3) = -178.198722;
model = svmtrain(train_label,train_data, '-s 0 -t 2 -c 1 -g 100 '    ); 
 
[predict_label, accuracy, dec_values] = svmpredict(test_label, test_data, model); % test the training data 
 
A = zeros(model.totalSV,model.totalSV);

K = zeros(model.totalSV,model.totalSV);

B_label = zeros(model.totalSV,1);





for i = 1:model.totalSV,
    for j =1:model.totalSV,
        K(i,j) = exp(-100*norm(model.SVs(i,:)-model.SVs(j,:))^2);
        A(i,j) = model.sv_coef(i) * model.sv_coef(j);
    end;
end;

S = A.*K;
SS = sum(S(:)); %||w||^2

B_label(1:model.totalSV) = train_label(model.sv_indices(1:model.totalSV));
B = model.sv_coef(1:model.totalSV)./(2*B_label(1:model.totalSV)-1);
BU = [];
nBU = 0;
for i=1:model.totalSV,
    if B(i) > -1
        BU = [BU ; model.sv_indices(i)];
        nBU = nBU + 1;
    end;
end;
B_dec = zeros(nBU,1);
for i =1:nBU,
    tmp = 0;
    for j = 1:model.totalSV,
        tmp = tmp + model.sv_coef(j) * K(j,i);
    end;
    B_dec(i) = (2*train_label(BU(i))-1)*(tmp -model.rho);
end;

B_dis = sqrt(abs(B_dec(1:nBU)).^2/SS);
O1(4) = nBU;
tmpSV_dis = zeros(7291,1);
tmpSV_dis(BU(1:nBU)) = B_dis(1:nBU);
for i = 1:7291,
    if SV_dis(i) ~= 0,
        if SV_dis(i) <= tmpSV_dis(i),
            O1(4) = -nBU;
        end;
    end;    
end;
SV_dis(BU(1:nBU)) = B_dis(1:nBU);


O2(4) = (-0.5*SS +1401.259572)/1;
O3(4) = model.totalSV;
O4(4) = accuracy(2);
O5(4) = -1401.259572;
model = svmtrain(train_label,train_data, '-s 0 -t 2 -c 10 -g 100 '    ); 
 
[predict_label, accuracy, dec_values] = svmpredict(test_label, test_data, model); % test the training data 
 
A = zeros(model.totalSV,model.totalSV);

K = zeros(model.totalSV,model.totalSV);

B_label = zeros(model.totalSV,1);





for i = 1:model.totalSV,
    for j =1:model.totalSV,
        K(i,j) = exp(-100*norm(model.SVs(i,:)-model.SVs(j,:))^2);
        A(i,j) = model.sv_coef(i) * model.sv_coef(j);
    end;
end;

S = A.*K;
SS = sum(S(:)); %||w||^2

B_label(1:model.totalSV) = train_label(model.sv_indices(1:model.totalSV));
B = model.sv_coef(1:model.totalSV)./(2*B_label(1:model.totalSV)-1);
BU = [];
nBU = 0;
for i=1:model.totalSV,
    if B(i) > -10
        BU = [BU ; model.sv_indices(i)];
        nBU = nBU + 1;
    end;
end;
B_dec = zeros(nBU,1);
for i =1:nBU,
    tmp = 0;
    for j = 1:model.totalSV,
        tmp = tmp + model.sv_coef(j) * K(j,i);
    end;
    B_dec(i) = (2*train_label(BU(i))-1)*(tmp -model.rho);
end;

B_dis = sqrt(abs(B_dec(1:nBU)).^2/SS);
O1(5) = nBU;
tmpSV_dis = zeros(7291,1);
tmpSV_dis(BU(1:nBU)) = B_dis(1:nBU);
for i = 1:7291,
    if SV_dis(i) ~= 0,
        if SV_dis(i) <= tmpSV_dis(i),
            O1(5) = -nBU;
        end;
    end;    
end;
SV_dis(BU(1:nBU)) = B_dis(1:nBU);


O2(5) = (-0.5*SS +13027.301309)/10;
O3(5) = model.totalSV;
O4(5) = accuracy(2);
O5(5) = -13027.301309;

O1
O2
O3
O4
O5

